-- MySQL dump 10.13  Distrib 8.3.0, for Linux (x86_64)
--
-- Host: localhost    Database: horo
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `text_blocks`
--

DROP TABLE IF EXISTS `text_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `text_blocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `variant` tinyint unsigned NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tone` enum('positive','negative','neutral') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neutral',
  `tokens_in` int unsigned NOT NULL DEFAULT '0',
  `tokens_out` int unsigned NOT NULL DEFAULT '0',
  `cost_usd` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `text_blocks_key_section_language_variant_unique` (`key`,`section`,`language`,`variant`),
  KEY `text_blocks_key_section_language_index` (`key`,`section`,`language`)
) ENGINE=InnoDB AUTO_INCREMENT=61724 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `text_blocks`
--
-- WHERE:  section='natal_ascendant'

LOCK TABLES `text_blocks` WRITE;
/*!40000 ALTER TABLE `text_blocks` DISABLE KEYS */;
INSERT INTO `text_blocks` VALUES (1899,'ascendant_in_aries','natal_ascendant','en',1,'People meet you and immediately notice your directness. You come across as <strong>straightforward and ready to act</strong> rather than cautious or reflective. You tend to speak first and think later, which makes you seem confident but sometimes tactless. In social situations you naturally take the lead because you move faster than most people do. Others often perceive you as bold or competitive even when you are just being your normal self.','neutral',343,119,0.000750,'2026-03-08 20:34:39','2026-03-08 20:34:39'),(1902,'ascendant_in_taurus','natal_ascendant','en',1,'People tend to see you as steady and reliable before they know much about you. You probably move and speak slowly, and you choose your words carefully. This makes you seem calm to others, even when you feel anxious on the inside. You likely dress in practical, comfortable clothes and prefer classic styles over trendy ones. Others often assume you are more patient and grounded than you actually are, which can create mismatches between how people treat you and what you actually need.','neutral',343,127,0.000782,'2026-03-08 20:34:41','2026-03-08 20:34:41'),(1904,'ascendant_in_gemini','natal_ascendant','en',1,'People often see you as <strong>quick to talk and easy to approach</strong>. You naturally pick up on small details in conversations and remember what others say. You tend to ask questions rather than make statements, which makes people feel heard. This can work well in social situations, though sometimes you might seem restless or like you are not fully committed to what you are saying.','neutral',343,108,0.000706,'2026-03-08 20:34:43','2026-03-08 20:34:43'),(1907,'ascendant_in_cancer','natal_ascendant','en',1,'People usually see you as careful and attentive to their feelings before they know much about you. You pick up on emotional cues quickly, so you notice when someone is upset even if they haven\'t said anything. This makes you seem protective and easy to confide in from the start. The downside is that you can come across as shy or cautious when you first meet people. You often need time to warm up before you show your actual personality.','neutral',341,123,0.000765,'2026-03-08 20:34:44','2026-03-08 20:34:44'),(1910,'ascendant_in_leo','natal_ascendant','en',1,'People notice you first because you move and speak with confidence. You tend to take up space in a room without trying too hard, and others often look to you to set the tone or make a decision. This works well when you want to lead or perform, but it can also make you feel like you always need to be on display. You probably find it easier to be outgoing than to blend into the background, even when you might prefer to.','neutral',341,121,0.000757,'2026-03-08 20:34:46','2026-03-08 20:34:46'),(1913,'ascendant_in_virgo','natal_ascendant','en',1,'People notice you as <strong>careful and put-together</strong>. You tend to organize things around you without being asked, and you pay attention to details that others miss. In conversations, you ask practical questions and want to understand how things actually work. You probably spend time on your appearance or environment because it matters to you how you look to others. This means you come across as reliable, but sometimes people think you are worried about things that do not really matter.','neutral',343,126,0.000778,'2026-03-08 20:34:48','2026-03-08 20:34:48'),(1916,'ascendant_in_libra','natal_ascendant','en',1,'People tend to see you as fair and interested in their opinions before you make decisions. You probably ask others what they think more often than you announce your own views right away. This habit makes you good in conversations where balance matters, like negotiating or mediating. The downside is that you can spend so much time weighing both sides that you delay saying what you actually want. You come across as someone who wants to keep things pleasant, which is useful socially but sometimes costs you clarity about your own preferences.','neutral',343,134,0.000810,'2026-03-08 20:34:51','2026-03-08 20:34:51'),(1919,'ascendant_in_scorpio','natal_ascendant','en',1,'People often find you hard to read at first. You don\'t volunteer information about yourself, and you watch others carefully before deciding who to trust. This makes you come across as <strong>reserved and intense</strong>, which can seem intimidating even when you\'re just being quiet. Once someone earns your trust, you show them a very different side. Your <em>Scorpio</em> rising means you\'re naturally drawn to understanding what\'s really going on beneath the surface, and you\'re not easily fooled by what people pretend to be.','neutral',343,144,0.000850,'2026-03-08 20:34:53','2026-03-08 20:34:53'),(1921,'ascendant_in_sagittarius','natal_ascendant','en',1,'People tend to see you as outgoing and direct the moment they meet you. You naturally make bold statements and ask questions without much filtering. This works well in casual settings where honesty is valued, but can come across as tactless in more formal situations. You probably find that strangers warm to you quickly because you seem confident, even when you are not sure what you are doing.','neutral',344,108,0.000707,'2026-03-08 20:34:54','2026-03-08 20:34:54'),(1923,'ascendant_in_capricorn','natal_ascendant','en',1,'You come across as someone who takes things seriously. People often assume you are more reserved or formal than you actually are, and they may approach you carefully at first. You tend to present yourself as competent and in control, which makes others trust you with responsibility. However, this can make it harder for you to show vulnerability or let people see you relax. Over time, people who know you well realize you have a dry sense of humor and genuine warmth underneath the professional exterior.','neutral',344,128,0.000787,'2026-03-08 20:34:56','2026-03-08 20:34:56'),(1926,'ascendant_in_aquarius','natal_ascendant','en',1,'People see you as someone who thinks differently and doesn\'t follow the crowd. You probably notice this in how others react to you when you first meet them—they seem curious but sometimes unsure what to make of you. You come across as <strong>independent and objective</strong>, which means people often ask for your perspective on practical problems. The downside is that you can seem distant or hard to read in social situations. You likely don\'t feel the need to prove yourself to others or fit in, which is both your strength and why some people find you difficult to get close to.','neutral',343,149,0.000870,'2026-03-08 20:34:58','2026-03-08 20:34:58'),(1929,'ascendant_in_pisces','natal_ascendant','en',1,'People often read you as softer or less direct than you actually are. You come across as approachable and willing to listen, which makes others comfortable sharing with you. This works well in social situations where you want to build trust quickly. The downside is that you might get pulled into other people\'s problems even when you do not want to be. You may need to be more explicit about your boundaries, because your calm presence can accidentally invite people to dump their feelings on you.','neutral',343,128,0.000786,'2026-03-08 20:35:00','2026-03-08 20:35:00');
/*!40000 ALTER TABLE `text_blocks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-11  8:28:07
