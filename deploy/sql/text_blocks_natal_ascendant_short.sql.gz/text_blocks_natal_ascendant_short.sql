-- MySQL dump 10.13  Distrib 8.3.0, for Linux (x86_64)
--
-- Host: localhost    Database: horo
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `text_blocks`
--

DROP TABLE IF EXISTS `text_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `text_blocks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `variant` tinyint unsigned NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tone` enum('positive','negative','neutral') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neutral',
  `tokens_in` int unsigned NOT NULL DEFAULT '0',
  `tokens_out` int unsigned NOT NULL DEFAULT '0',
  `cost_usd` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `text_blocks_key_section_language_variant_unique` (`key`,`section`,`language`,`variant`),
  KEY `text_blocks_key_section_language_index` (`key`,`section`,`language`)
) ENGINE=InnoDB AUTO_INCREMENT=61724 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `text_blocks`
--
-- WHERE:  section='natal_ascendant_short'

LOCK TABLES `text_blocks` WRITE;
/*!40000 ALTER TABLE `text_blocks` DISABLE KEYS */;
INSERT INTO `text_blocks` VALUES (1898,'ascendant_in_aries','natal_ascendant_short','en',1,'Direct and bold in self-presentation, coming across as confident and quick to act in new situations.','neutral',290,50,0.000432,'2026-03-08 20:34:38','2026-03-08 20:34:38'),(1900,'ascendant_in_taurus','natal_ascendant_short','en',1,'Presents as <strong>steady and grounded</strong>, with a practical approach to appearance and material comfort.','neutral',290,53,0.000444,'2026-03-08 20:34:39','2026-03-08 20:34:39'),(1901,'ascendant_in_gemini','natal_ascendant_short','en',1,'First impression is <strong>curious, talkative, and quick to adapt</strong> to new situations.','neutral',290,53,0.000444,'2026-03-08 20:34:40','2026-03-08 20:34:40'),(1903,'ascendant_in_cancer','natal_ascendant_short','en',1,'Projects a <strong>protective, emotionally aware presence</strong> that makes others feel safe and understood.','neutral',288,52,0.000438,'2026-03-08 20:34:42','2026-03-08 20:34:42'),(1905,'ascendant_in_leo','natal_ascendant_short','en',1,'<strong>Confident and attention-grabbing presence</strong> that draws people in naturally.','positive',288,49,0.000426,'2026-03-08 20:34:43','2026-03-08 20:34:43'),(1906,'ascendant_in_virgo','natal_ascendant_short','en',1,'First impression is <strong>practical and detail-focused</strong>, with noticeable care for order and efficiency.','neutral',290,54,0.000448,'2026-03-08 20:34:44','2026-03-08 20:34:44'),(1908,'ascendant_in_libra','natal_ascendant_short','en',1,'First impression centres on <strong>balance, politeness, and careful listening</strong> to others\' perspectives.','neutral',290,53,0.000444,'2026-03-08 20:34:45','2026-03-08 20:34:45'),(1909,'ascendant_in_scorpio','natal_ascendant_short','en',1,'Presents as <strong>intense and perceptive</strong>, with a private manner that draws others in through mystery.','neutral',290,55,0.000452,'2026-03-08 20:34:46','2026-03-08 20:34:46'),(1911,'ascendant_in_sagittarius','natal_ascendant_short','en',1,'Appears <strong>optimistic and approachable</strong> to others, with natural confidence in new situations.','positive',291,54,0.000449,'2026-03-08 20:34:47','2026-03-08 20:34:47'),(1912,'ascendant_in_capricorn','natal_ascendant_short','en',1,'Appears <strong>reserved and serious</strong> in first impressions, with a practical approach to how the world sees them.','neutral',291,57,0.000461,'2026-03-08 20:34:48','2026-03-08 20:34:48'),(1914,'ascendant_in_aquarius','natal_ascendant_short','en',1,'Appears <strong>detached and unconventional</strong> to others, with an aloof first impression.','neutral',290,54,0.000448,'2026-03-08 20:34:49','2026-03-08 20:34:49'),(1915,'ascendant_in_pisces','natal_ascendant_short','en',1,'First impression is <strong>soft and intuitive</strong>, often appearing dreamy or emotionally open to others.','neutral',290,54,0.000448,'2026-03-08 20:34:50','2026-03-08 20:34:50');
/*!40000 ALTER TABLE `text_blocks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-11  8:28:07
